package com.example.app375

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
