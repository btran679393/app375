import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'BTAnime',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple),
        useMaterial3: true,
      ),
      home: const MyHomePage(),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({super.key});

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  final TextEditingController _searchController = TextEditingController();
  final List<Map<String, dynamic>> _animeList = [
    {'title': 'Attack on Titan', 'image': 'assets/AttackonTitan.jpg', 'seasons': 4, 'episodesPerSeason': [25, 12, 22, 28]},
    {'title': 'Naruto', 'image': 'assets/Naruto.jpg', 'seasons': 5, 'episodesPerSeason': [57, 43, 41, 42, 37]},
    {'title': 'One Piece', 'image': 'assets/onepc.jpg', 'seasons': 20, 'episodesPerSeason': List.generate(20, (index) => 50)},
    {'title': 'Demon Slayer', 'image': 'assets/DemonSlayer.jpg', 'seasons': 3, 'episodesPerSeason': [26, 11, 18]},
    {'title': 'Jujutsu Kaisen', 'image': 'assets/JJK.jpg', 'seasons': 2, 'episodesPerSeason': [24, 23]},
    {'title': 'Bleach', 'image': 'assets/Bleach.jpg', 'seasons': 16, 'episodesPerSeason': List.generate(16, (index) => 20)},
    {'title': 'Solo Leveling', 'image': 'assets/SoloLevling.jpg', 'seasons': 1, 'episodesPerSeason': [12]},
    {'title': 'Chainsaw Man', 'image': 'assets/Chainsaw.jpg', 'seasons': 1, 'episodesPerSeason': [12]},
    {'title': 'My Hero Academia', 'image': 'assets/MyHero.jpg', 'seasons': 6, 'episodesPerSeason': [13, 25, 25, 25, 25, 25]},
    {'title': 'Tokyo Revengers', 'image': 'assets/Tokyo.jpg', 'seasons': 2, 'episodesPerSeason': [24, 13]},
    {'title': 'Your Lie in April', 'image': 'assets/Yourlie.jpg', 'seasons': 1, 'episodesPerSeason': [22]},
    {'title': 'Toradora!', 'image': 'assets/Toradora.jpg', 'seasons': 1, 'episodesPerSeason': [25]},
    {'title': 'Clannad', 'image': 'assets/Clannad.jpg', 'seasons': 2, 'episodesPerSeason': [23, 24]},
    {'title': 'Kaguya-sama: Love Is War', 'image': 'assets/Love.jpg', 'seasons': 3, 'episodesPerSeason': [12, 12, 13]},
    {'title': 'Fruits Basket', 'image': 'assets/Fruit.jpg', 'seasons': 3, 'episodesPerSeason': [25, 25, 13]},
    {'title': 'Horimiya', 'image': 'assets/Horimiya.jpg', 'seasons': 1, 'episodesPerSeason': [13]},
    {'title': 'The Quintessential Quintuplets', 'image': 'assets/Tqq.jpg', 'seasons': 2, 'episodesPerSeason': [12, 12]},
  ];

  List<Map<String, dynamic>> _filteredAnime = [];

  @override
  void initState() {
    super.initState();
    _filteredAnime = _animeList;
  }

  void _filterAnime(String query) {
    setState(() {
      _filteredAnime = _animeList
          .where((anime) => anime['title']!.toLowerCase().contains(query.toLowerCase()))
          .toList();
    });
  }

  void _navigateToAnimeDetail(BuildContext context, Map<String, dynamic> anime) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => AnimeSeasonsPage(anime: anime),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.green,
        title: const Text(
          "BTAnime",
          style: TextStyle(color: Colors.black),
        ),
      ),
      backgroundColor: Colors.black,
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SizedBox(height: 20),
            const Text(
              "BTAnime",
              style: TextStyle(
                color: Colors.white,
                fontSize: 28,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 30),
            TextField(
              controller: _searchController,
              style: const TextStyle(color: Colors.white),
              decoration: InputDecoration(
                hintText: "Search for anime...",
                hintStyle: const TextStyle(color: Colors.white70),
                filled: true,
                fillColor: Colors.grey[800],
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8),
                  borderSide: BorderSide.none,
                ),
                prefixIcon: const Icon(Icons.search, color: Colors.white),
              ),
              onChanged: _filterAnime,
            ),
            const SizedBox(height: 20),
            Expanded(
              child: ListView.builder(
                itemCount: _filteredAnime.length,
                itemBuilder: (context, index) {
                  return Card(
                    color: Colors.grey[900],
                    child: ListTile(
                      leading: Image.network(
                        _filteredAnime[index]['image']!,
                        width: 50,
                        height: 50,
                        fit: BoxFit.cover,
                      ),
                      title: Text(
                        _filteredAnime[index]['title']!,
                        style: const TextStyle(color: Colors.white),
                      ),
                      onTap: () => _navigateToAnimeDetail(context, _filteredAnime[index]),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
class AnimeSeasonsPage extends StatelessWidget {
  final Map<String, dynamic> anime;

  const AnimeSeasonsPage({super.key, required this.anime});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.green,
        title: Text(anime['title']!, style: const TextStyle(color: Colors.black)),
      ),
      backgroundColor: Colors.black,
      body: ListView.builder(
        itemCount: anime['seasons'],
        itemBuilder: (context, seasonIndex) {
          return ExpansionTile(
            title: Row(
              children: [
                Image.network(
                  anime['image']!,
                  fit: BoxFit.cover,
                ),
                const SizedBox(width: 8),
                Text(
                  'Season ${seasonIndex + 1}',
                  style: const TextStyle(color: Colors.white, fontSize: 18),
                ),
              ],
            ),
            children: List.generate(anime['episodesPerSeason'][seasonIndex], (episodeIndex) {
              return ListTile(
                title: Text(
                  'Episode ${episodeIndex + 1}',
                  style: const TextStyle(color: Colors.white),
                ),
              );
            }),
          );
        },
      ),
    );
  }
}
